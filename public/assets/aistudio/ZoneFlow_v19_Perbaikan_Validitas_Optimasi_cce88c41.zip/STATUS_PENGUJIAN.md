# STATUS PENGUJIAN — PERBAIKAN VALIDITAS OPTIMASI ZONEFLOW V19

**Tanggal audit:** 29 Oktober 2026. **Dasar:** file `zoneflow (19).zip`, `Blueprint_AZBO.pdf`, `Audit_ZoneFlow.pdf`, dan empat PDF referensi metode yang diberikan pengguna.

| Pengecekan yang BENAR-BENAR dijalankan di lingkungan audit ini | Hasil |
| --- | --- |
| `PYTHONPATH=backend python -m unittest discover -s backend/tests -v` | **32/32 lulus**, 0 gagal (lihat `TES_BACKEND_AKTUAL.log`); terdiri dari 27 tes lama dan 5 tes baru. |
| Pemeriksaan cakupan GA N=30, GA population 14 | **30/30 nilai K tercakup dan dievaluasi** setidaknya satu calon per K; dievaluasi pada seed TRAIN. |
| Simulasi 180 kursi, 60% pembawa bagasi, 100 TEST replications, 12 metode | **Berhasil**, contoh skenario pada `CONTOH_DIAGNOSTIK_180_100REPLIKASI.json` (≈29 s di lingkungan audit), bukan hasil boarding empiris. |
| Validitas trace pemenang, seed TEST independen dari TRAIN, kesetaraan urutan | **Lulus tes baru**. |
| Verifikasi bibliografi empat PDF yang diunggah | **Dikoreksi** di `DOKUMENTASI_METODE_JURNAL.md` berdasarkan halaman pertama PDF. |
| `npm ci --offline --ignore-scripts` | **Tidak berhasil memasang dependensi**: `ENOTCACHED` untuk paket `ws`. Ini masalah ketersediaan paket dalam lingkungan audit, BUKAN bukti build proyek gagal. |
| `npm run lint`, `npm run build`, tes React/Vite di browser pada salinan ini | **Belum diverifikasi** karena dependensi JS tidak terpasang. Jangan melaporkannya sebagai PASS. |
| Deployment FastAPI dan GitHub Pages | **Belum diverifikasi** pada layanan publik; proses di localhost bukan bukti deployment selesai. |

Catatan: klaim 15/15 tes frontend, `tsc PASS`, `vite build PASS`, dan uji browser sukses dalam `STATUS_PENGUJIAN.md` versi 19 lama **tidak diverifikasi ulang** oleh audit ini dan sengaja tidak dipertahankan sebagai status baru.

**Lingkup:** Keselarasan *aturan kode* dengan Blueprint, bukan pembuktian kesamaan durasi dengan boarding lapangan. Kesamaan hasil dengan publikasi jurnal juga tidak otomatis diharapkan karena model penumpang, definisi kelompok, layout, dan seed berbeda.

**Replikasi penelitian:** default UI tetap 20 replikasi untuk demo cepat. Untuk audit utama yang mengikuti acuan minimal 100 dari dokumen Audit ZoneFlow, set `VITE_AZBO_TEST_REPS=100` SEBELUM build frontend. Parameter ini membutuhkan backend Python yang mampu menyelesaikan job lebih panjang. Sesuaikan ukuran sampel dengan ketelitian yang dibutuhkan dan ulangi pada beberapa seed.
